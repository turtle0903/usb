@echo OFF
REM Enable Test Signing
bcdedit -set loadoptions ENABLE_INTEGRITY_CHECKS
bcdedit /set TESTSIGNING ON

REM Add registry key
reg add HKLM\SYSTEM\CurrentControlSet\Services\Usb4HostRouter\Parameters /v UserControlOfIdleSettings /t REG_DWORD /d 1

REM Tell user to reboot for changes to take effect.
echo Please reboot for changes to take effect.